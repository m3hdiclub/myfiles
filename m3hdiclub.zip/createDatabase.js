const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// مسیر دیتابیس
const dbPath = path.join(__dirname, 'm3hdiclub.db');

// اتصال به دیتابیس
const db = new sqlite3.Database(dbPath);

// ساخت جدول‌ها
db.serialize(() => {
    // ساخت جدول Users
    db.run(`
        CREATE TABLE IF NOT EXISTS Users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    `, (err) => {
        if (err) {
            console.error('Error creating Users table:', err.message);
        } else {
            console.log('Users table created successfully');

            // اضافه کردن کاربر پیش‌فرض
            const insertStmt = db.prepare("INSERT INTO Users (username, password) VALUES (?, ?)");
            insertStmt.run("00", "00", (err) => {
                if (err) {
                    console.error('Error inserting default user:', err.message);
                } else {
                    console.log('Default user inserted successfully');
                }

                // بستن اتصال به دیتابیس پس از اتمام عملیات
                db.close((err) => {
                    if (err) {
                        console.error('Error closing the database:', err.message);
                    } else {
                        console.log('Database connection closed');
                    }
                });
            });
            insertStmt.finalize();
        }
    });

    // ساخت جدول Customers
    db.run(`
        CREATE TABLE IF NOT EXISTS Customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            startDate TEXT NOT NULL,
            endDate TEXT NOT NULL,
            service TEXT NOT NULL,
            payment TEXT NOT NULL,
            telegramUser TEXT NOT NULL,
            description TEXT
        )
    `, (err) => {
        if (err) {
            console.error('Error creating Customers table:', err.message);
        } else {
            console.log('Customers table created successfully');
        }
    });

    // ساخت جدول Products
    db.run(`
        CREATE TABLE IF NOT EXISTS Products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            price REAL
        )
    `, (err) => {
        if (err) {
            console.error('Error creating Products table:', err.message);
        } else {
            console.log('Products table created successfully');
        }
    });
});
