document.addEventListener('DOMContentLoaded', async () => {
    // بارگذاری نام محصولات از سرور
    try {
        const response = await fetch('/products');
        const products = await response.json();
        const serviceSelect = document.getElementById('service');

        // اضافه کردن نام محصولات به فهرست انتخاب
        products.forEach(product => {
            const option = document.createElement('option');
            option.value = product.name; // مقدار گزینه
            option.textContent = product.name; // متن گزینه
            serviceSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Error fetching products:', error);
    }

    // بررسی وضعیت ورود به سیستم
    // حذف وضعیت ورود برای اجبار به ورود مجدد
    sessionStorage.removeItem('loggedIn');

    const isLoggedIn = sessionStorage.getItem('loggedIn');
    if (isLoggedIn === 'true') {
        document.getElementById('login-page').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
    } else {
        document.getElementById('login-page').style.display = 'flex';
        document.getElementById('main-content').style.display = 'none';
    }
	
	document.getElementById('fullname').addEventListener('input', formatFullName);
	
    document.getElementById('find_fullname').addEventListener('input', formatFullName);
	
	// نمایش تاریخ و زمان
    function updatePersianDate() {
        const persianDate = new Date().toLocaleDateString('fa-IR');
        const persianTime = new Date().toLocaleTimeString('fa-IR');
        document.getElementById('persian-date').innerText = `${persianDate} ${persianTime}`;
    }
    setInterval(updatePersianDate, 1000);
});

function showPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        if (page.id === pageId) {
            page.style.display = 'block';
        } else {
            page.style.display = 'none';
        }
    });
}

function convertPersianNumbersToEnglish(text) {
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

    return text.split('').map(char => {
        const index = persianDigits.indexOf(char);
        return index !== -1 ? englishDigits[index] : char;
    }).join('');
}


async function saveCustomer() {
    const fullname = document.getElementById('fullname').value;
    const service = document.getElementById('service').value;
    const description = document.getElementById('description').value;
    const payment = document.getElementById('payment').value;
    const telegram = document.getElementById('telegram').value;
    const duringDate = document.getElementById('duringdate').value;

    if (!fullname || !service || !payment || !duringDate) {
        alert("Please fill in all required fields.");
        return;
    }

    const startDate = new Date().toLocaleDateString('fa-IR');
    const start = new Date();
    const monthsToAdd = parseInt(duringDate);
    const endDate = new Date(start.setMonth(start.getMonth() + monthsToAdd)).toLocaleDateString('fa-IR');

    // تبدیل تاریخ‌های فارسی به لاتین
    const startDateEnglish = convertPersianNumbersToEnglish(startDate);
    const endDateEnglish = convertPersianNumbersToEnglish(endDate);

    try {
        // جستجوی اطلاعات تلگرام بر اساس نام کاربری
        const response = await fetch(`/find-customer?name=${encodeURIComponent(fullname)}`);
        const customers = await response.json();
        let telegramValue = '';

        if (customers.length > 0) {
            telegramValue = customers[0].telegramUser || '';
        }

        // ارسال اطلاعات مشتری به سرور
        const saveResponse = await fetch('/save-customer', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                fullname,
                service,
                description,
                payment,
                telegram: telegram || telegramValue, // استفاده از مقدار تلگرام از دیتابیس اگر خالی باشد
                startdate: startDateEnglish,
                enddate: endDateEnglish
            })
        });

        const result = await saveResponse.json();

        if (result.success) {
            alert("Customer saved successfully.");
        } else {
            alert("Failed to save customer.");
        }
    } catch (error) {
        console.error('Error:', error);
        alert("Error occurred while saving customer.");
    }

    clearForm();
}


function clearForm() {
    document.getElementById('fullname').value = '';
    document.getElementById('service').selectedIndex = 0;
    document.getElementById('description').value = '';
    document.getElementById('payment').selectedIndex = 0;
    document.getElementById('telegram').value = '';
    document.getElementById('startdate').value = '';
    document.getElementById('enddate').value = '';
}

async function formatFullName() {
    const inputFields = ['fullname', 'find_fullname'];
    
    inputFields.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            let text = input.value;

            let words = text.split(/\s+/).filter(word => word.length > 0);

            if (words.length >= 2) {
                words = words.map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase());
                input.value = words.join(' ');
            } else {
                if (text.length > 0) {
                    input.value = text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
                }
            }
        }
    });
}


function formatNumberWithCommas(number) {
    // حذف قسمت اعشاری اگر برابر با 00 باشد و تبدیل عدد به رشته با اضافه کردن کاما
    const [integerPart] = number.toString().split('.');
    return integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

async function findCustomer() {
    const fullname = document.getElementById('find_fullname').value.trim().toLowerCase();
    const month = document.getElementById('month_select').value;

    formatFullName();

    try {
        let url = `/find-customer?name=${encodeURIComponent(fullname)}`;
        if (month && month !== 'all') {
            const monthMap = {
                farvardin: '1403/1',
                ordibehesht: '1403/2',
                khordad: '1403/3',
                tir: '1403/4',
                mordad: '1403/5',
                shahrivar: '1403/6',
                mehr: '1403/7',
                aban: '1403/8',
                azar: '1403/9',
                dey: '1403/10',
                bahman: '1403/11',
                esfand: '1403/12'
            };
            const startDate = monthMap[month];
            url += `&startDate=${encodeURIComponent(startDate)}`;
        }

        const response = await fetch(url);
        const customers = await response.json();

        console.log('Customers:', customers);

        const tbody = document.querySelector('#results_table tbody');
        tbody.innerHTML = '';

        if (customers.length > 0) {
            let totalPrice = 0;
            for (const customer of customers) {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${customer.name || 'N/A'}</td>
                    <td>${customer.startDate || 'N/A'}</td>
                    <td>${customer.endDate || 'N/A'}</td>
                    <td>${customer.service || 'N/A'}</td>
                    <td>${customer.payment || 'N/A'}</td>
                    <td>${customer.telegramUser || 'N/A'}</td>
                    <td>${customer.description || 'N/A'}</td>
                `;
                tbody.appendChild(row);

                const servicePriceResponse = await fetch(`/service-price?name=${encodeURIComponent(customer.service)}`);
                const servicePrice = await servicePriceResponse.json();
                totalPrice += servicePrice;
            }

            document.getElementById('total_price').innerText = `Total Price: ${formatNumberWithCommas(totalPrice)} T`;
        } else {
            document.getElementById('total_price').innerText = 'No results found';
        }
    } catch (error) {
        console.error('Error fetching customer data:', error);
    }
}

async function showAllCustomers() {
    const month = document.getElementById('month_select').value;
    const day = document.getElementById('day_select').value;
    let url = '/all-customers';

    const monthMap = {
        farvardin: '1403/1',
        ordibehesht: '1403/2',
        khordad: '1403/3',
        tir: '1403/4',
        mordad: '1403/5',
        shahrivar: '1403/6',
        mehr: '1403/7',
        aban: '1403/8',
        azar: '1403/9',
        dey: '1403/10',
        bahman: '1403/11',
        esfand: '1403/12'
    };

    if (month === 'all' && !day) {
        // نمایش همه سطرها وقتی ماه "all" انتخاب شده باشد
        try {
            const response = await fetch(url);
            const customers = await response.json();

            console.log('All Customers:', customers);

            const tbody = document.querySelector('#results_table tbody');
            tbody.innerHTML = '';

            if (customers.length > 0) {
                let totalPrice = 0;
                for (const customer of customers) {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${customer.name || 'N/A'}</td>
                        <td>${customer.startDate || 'N/A'}</td>
                        <td>${customer.endDate || 'N/A'}</td>
                        <td>${customer.service || 'N/A'}</td>
                        <td>${customer.payment || 'N/A'}</td>
                        <td>${customer.telegramUser || 'N/A'}</td>
                        <td>${customer.description || 'N/A'}</td>
                    `;
                    tbody.appendChild(row);

                    const servicePriceResponse = await fetch(`/service-price?name=${encodeURIComponent(customer.service)}`);
                    const servicePrice = await servicePriceResponse.json();
                    totalPrice += servicePrice;
                }

                document.getElementById('total_price').innerText = `Total Price: ${formatNumberWithCommas(totalPrice)} T`;
            } else {
                document.getElementById('total_price').innerText = 'No information available';
            }
        } catch (error) {
            console.error('Error fetching all customers:', error);
        }
    } else if (month && !day) {
        // فیلتر بر اساس ماه خاص
        const startDate = monthMap[month];
        url += `?startDate=${encodeURIComponent(startDate)}`;

        try {
            const response = await fetch(url);
            const customers = await response.json();

            console.log('Filtered Customers:', customers);

            const tbody = document.querySelector('#results_table tbody');
            tbody.innerHTML = '';

            if (customers.length > 0) {
                let totalPrice = 0;
                for (const customer of customers) {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${customer.id || 'N/A'}</td>
                        <td>${customer.name || 'N/A'}</td>
                        <td>${customer.startDate || 'N/A'}</td>
                        <td>${customer.endDate || 'N/A'}</td>
                        <td>${customer.service || 'N/A'}</td>
                        <td>${customer.payment || 'N/A'}</td>
                        <td>${customer.telegramUser || 'N/A'}</td>
                        <td>${customer.description || 'N/A'}</td>
                    `;
                    tbody.appendChild(row);

                    const servicePriceResponse = await fetch(`/service-price?name=${encodeURIComponent(customer.service)}`);
                    const servicePrice = await servicePriceResponse.json();
                    totalPrice += servicePrice;
                }

                document.getElementById('total_price').innerText = `Total Price: ${formatNumberWithCommas(totalPrice)} T`;
            } else {
                document.getElementById('total_price').innerText = 'No results found';
            }
        } catch (error) {
            console.error('Error fetching filtered customers:', error);
        }
    } else if (month && day) {
        // فیلتر بر اساس ماه و روز خاص
        const startDate = `${monthMap[month]}/${day}`;
        url += `?startDate=${encodeURIComponent(startDate)}`;

        try {
            const response = await fetch(url);
            const customers = await response.json();

            console.log('Filtered Customers with Day:', customers);

            const tbody = document.querySelector('#results_table tbody');
            tbody.innerHTML = '';

            if (customers.length > 0) {
                let totalPrice = 0;
                for (const customer of customers) {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${customer.id || 'N/A'}</td>
                        <td>${customer.name || 'N/A'}</td>
                        <td>${customer.startDate || 'N/A'}</td>
                        <td>${customer.endDate || 'N/A'}</td>
                        <td>${customer.service || 'N/A'}</td>
                        <td>${customer.payment || 'N/A'}</td>
                        <td>${customer.telegramUser || 'N/A'}</td>
                        <td>${customer.description || 'N/A'}</td>
                    `;
                    tbody.appendChild(row);

                    const servicePriceResponse = await fetch(`/service-price?name=${encodeURIComponent(customer.service)}`);
                    const servicePrice = await servicePriceResponse.json();
                    totalPrice += servicePrice;
                }

                document.getElementById('total_price').innerText = `Total Price: ${formatNumberWithCommas(totalPrice)} T`;
            } else {
                document.getElementById('total_price').innerText = 'No results found';
            }
        } catch (error) {
            console.error('Error fetching filtered customers with day:', error);
        }
    } else {
        // وقتی که هیچ آیتمی از کمبوباکس انتخاب نشده باشد
        document.getElementById('results_table').getElementsByTagName('tbody')[0].innerHTML = '';
        document.getElementById('total_price').innerText = 'No information available';
    }
}


document.addEventListener('DOMContentLoaded', function() {
    // نمایش تاریخ و ساعت
    function updatePersianDate() {
        const persianDate = new Date().toLocaleDateString('fa-IR');
        const persianTime = new Date().toLocaleTimeString('fa-IR');
        document.getElementById('persian-date').innerText = `${persianDate} ${persianTime}`;
    }
    setInterval(updatePersianDate, 1000);

    // ارسال فرم ورود
    document.getElementById('login-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();

        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // ذخیره وضعیت ورود و نمایش فرم اصلی
                sessionStorage.setItem('loggedIn', 'true');
                document.getElementById('login-page').style.display = 'none';
                document.getElementById('main-content').style.display = 'block';
            } else {
                document.getElementById('error-message').innerText = 'نام کاربری یا رمز عبور اشتباه است';
            }
        })
        .catch(error => console.error('Error:', error));
    });

    // ارسال فرم تغییر رمز عبور
    document.getElementById('change-password-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const newUsername = document.getElementById('new-username').value.trim();
        const newPassword = document.getElementById('new-password').value.trim();

        fetch('/change-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ newUsername, newPassword })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('message').innerText = 'تغییر نام کاربری و رمز عبور با موفقیت انجام شد';
                setTimeout(() => {
                    sessionStorage.removeItem('loggedIn'); // حذف وضعیت ورود
                    window.location.href = 'index.html'; // هدایت به صفحه ورود
                }, 2000);
            } else {
                document.getElementById('message').innerText = data.message;
            }
        })
        .catch(error => console.error('Error:', error));
    });
});

async function backupDatabase() {
    try {
        const response = await fetch('/export-db', {
            method: 'GET'
        });
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = 'm3hdiclub.db';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        alert("Database exported successfully.");
    } catch (error) {
        console.error('Error exporting database:', error);
        alert("Error occurred while exporting database.");
    }
}

function resetSearch() {
    document.getElementById('find_fullname').value = ''; // خالی کردن فیلد نام کامل
    document.getElementById('month_select').value = ''; // بازنشانی کمبوباکس به حالت پیش‌فرض (گزینه خالی)
	document.getElementById('day_select').value = ''; // بازنشانی کمبوباکس به حالت پیش‌فرض (گزینه خالی)
    document.querySelector('#results_table tbody').innerHTML = ''; // پاک کردن جدول نتایج
    document.getElementById('total_price').innerText = ''; // پاک کردن قیمت کل
}

async function showLastCustomers() {
    const persianDate = new Date().toLocaleDateString('fa-IR');
    const persianDateEnglish = convertPersianNumbersToEnglish(persianDate);

    try {
        const response = await fetch(`/last-customers?endDate=${encodeURIComponent(persianDateEnglish)}`);
        const customers = await response.json();

        const tbody = document.querySelector('#last_customers_table tbody');
        tbody.innerHTML = '';

        if (customers.length > 0) {
            for (const customer of customers) {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${customer.name || 'N/A'}</td>
                    <td>${customer.startDate || 'N/A'}</td>
                    <td>${customer.endDate || 'N/A'}</td>
                    <td>${customer.service || 'N/A'}</td>
                    <td>${customer.payment || 'N/A'}</td>
                    <td>${customer.telegramUser || 'N/A'}</td>
                    <td>${customer.description || 'N/A'}</td>
                `;
                tbody.appendChild(row);
            }
        } else {
            tbody.innerHTML = '<tr><td colspan="8">No results found</td></tr>';
        }
    } catch (error) {
        console.error('Error fetching last customers:', error);
    }
}